#include<bits/stdc++.h>
using namespace std;
signed main(){
	cout << "$5 ��5";
	return 0;
} 
